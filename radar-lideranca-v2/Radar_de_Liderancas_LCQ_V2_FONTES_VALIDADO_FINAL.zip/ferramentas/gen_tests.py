import sys,re,json
sys.path.insert(0,'tools'); from rep import get_prop, _expr_end, _match_end
SRC='src_work/Src/'
def P(f,c,p): return get_prop(SRC+f,c,p)[1:]
def field(text,key):
    m=re.search(r'\b'+re.escape(key)+r'\s*[:,]\s*',text); assert m,key
    e=_expr_end(text,m.end()); return text[m.end():e].strip()
def setarg(text,var):
    m=re.search(r'Set\(\s*'+var+r'\s*,\s*',text); assert m,var
    e=_expr_end(text,m.end()); return text[m.end():e].strip()
def nocomments(t): return re.sub(r'(?m)^\s*//.*$','',t)
def flat(t):
    t=re.sub(r'\s+',' ',nocomments(t)); t=re.sub(r'\(\s+','(',t); return re.sub(r'\s+\)',')',t)
T=[]
def add(name,expr,expected,**vars): T.append(dict(name=name,expr=expr,expected=str(expected),vars=vars))
# ---------- 1. Menu por perfil (App.OnStart) ----------
app=nocomments(P('App.pa.yaml','App','OnStart'))
i=app.index('colMenu,'); j=app.index('Table(',i); menu=app[j:_match_end(app,j+5)]
for perfil,cad,lid,adm,exp in [('SemAcesso','false','false','false','Cockpit,Guia'),
    ('Integrante','true','false','false','Cockpit,Demandas,Equipamentos,Rotina,Decisoes,Guia'),
    ('Lideranca','true','true','false','Cockpit,Demandas,Capacidade,Equipamentos,Rotina,Auditoria,Decisoes,Guia,Administracao'),
    ('Administrador','true','true','true','Cockpit,Demandas,Capacidade,Equipamentos,Rotina,Auditoria,Decisoes,Guia,Administracao')]:
    add(f'Menu visível perfil {perfil}',f'Concat(SortByColumns(Filter({menu}, Visivel), "Ordem", SortOrder.Ascending), Chave, ",")',exp,varUsuarioCadastrado=cad,varEhLideranca=lid,varEhAdmin=adm)
# ---------- 2. Pesos: soma e fallback ----------
soma=setarg(app,'varSomaPesosConfig'); val=setarg(app,'varPesosConfigValidos')
for (a,b,c,d,ok) in [(0.40,0.30,0.20,0.10,'true'),(0.40,0.30,0.20,0.05,'false'),(0.25,0.25,0.25,0.25,'true')]:
    add(f'Soma pesos {a}+{b}+{c}+{d} válida',f'With({{varSomaPesosConfig: {soma}}}, {val})',ok,varPesoEsforco=str(a),varPesoImpacto=str(b),varPesoUrgencia=str(c),varPesoRisco=str(d))
# ---------- 3. IPD / CargaReal (btnSalvarDemanda) ----------
sd=nocomments(P('TelaDemandas.pa.yaml','btnSalvarDemanda','OnSelect'))
carga=field(sd,'vCargaReal')
for (e,i_,u,r,exp) in [(1,1,1,1,'1'),(4,4,4,4,'4'),(4,3,3,2,'3.3'),(2,4,1,3,'2.5'),(3,2,4,1,'2.7')]:
    add(f'IPD E{e} I{i_} U{u} R{r}',f'Text({carga}, "0.00")',f'{float(exp):.2f}',vEsforco=str(e),vImpacto=str(i_),vUrgencia=str(u),vRisco=str(r),varPesoEsforco='0.40',varPesoImpacto='0.30',varPesoUrgencia='0.20',varPesoRisco='0.10')
imp=field(sd,'vImpacto').replace('drpConsequencia.Selected.Value','pResp')
add('IPD: resposta Impacto nível 4',imp,'4',pResp='"Risco de parada, auditoria, segurança ou não conformidade"')
add('IPD: pergunta sem resposta -> Blank (bloqueia gravação)',f'IsBlank({imp})','true',pResp='Blank()')
add('IPD: resposta fora da escala -> Blank',f'IsBlank({imp})','true',pResp='"Valor antigo escala 5"')
# guarda de permissão do salvar
g=re.search(r'!\(\s*\(varModoDemanda = "Nova" && varUsuarioCadastrado\) \|\|\s*\(varModoDemanda = "Editar" && varPodeEditarDemanda\)\s*\)',sd).group(0)
for modo,cad,pode,exp in [('Nova','true','false','false'),('Nova','false','false','true'),('Editar','true','true','false'),('Editar','true','false','true'),('Visualizar','true','true','true')]:
    add(f'Demanda: bloqueio de permissão modo={modo} cadastrado={cad} podeEditar={pode}',g,exp,varModoDemanda=f'"{modo}"',varUsuarioCadastrado=cad,varPodeEditarDemanda=pode)
# ---------- 4. Administração: elevação de privilégio ----------
si=nocomments(P('TelaAdministracao.pa.yaml','btnSalvarIntegranteAdmin','OnSelect'))
m=re.search(r'!varEhAdmin &&\s*\(\s*ddPerfilIntegranteAdmin\.Selected\.Value = "Administrador" \|\|.*?\)\s*\)',si,re.S); guard=m.group(0)
guard=guard.replace('ddPerfilIntegranteAdmin.Selected.Value','pPerfilNovo').replace('varIntegranteAdminSelecionado.Perfil.Value','pPerfilAtual')
for adm,modo,novo,atual,exp,desc in [
    ('false','Editar','Administrador','Lideranca','true','Liderança tenta se autoelevar'),
    ('false','Editar','Administrador','Integrante','true','Liderança promove terceiro a Administrador'),
    ('false','Novo','Administrador','""','true','Liderança cria integrante Administrador'),
    ('false','Editar','Lideranca','Administrador','true','Liderança rebaixa/edita Administrador'),
    ('false','Editar','Lideranca','Integrante','false','Liderança promove Integrante a Liderança (permitido)'),
    ('false','Novo','Integrante','""','false','Liderança cadastra Integrante (permitido)'),
    ('true','Editar','Administrador','Integrante','false','Administrador promove a Administrador (permitido)')]:
    add(f'Admin: {desc}',guard,exp,varEhAdmin=adm,varModoIntegranteAdmin=f'"{modo}"',pPerfilNovo=f'"{novo}"',pPerfilAtual=atual if atual=='""' else f'"{atual}"')
# duplicidade de e-mail (case-insensitive, exclui o próprio ID)
dup=re.search(r'LookUp\(\s*Radar_Integrantes,.*?ID\s*\)',si,re.S).group(0).replace('txtEmailIntegranteAdmin.Text','pEmail')
TI='Table({ID: 1, Email: "Ana.Silva@braskem.com"}, {ID: 2, Email: "joao@braskem.com"})'
add('Integrante: e-mail duplicado (maiúsculas diferentes)',f'!IsBlank({dup})','true',Radar_Integrantes=TI,pEmail='" ana.silva@BRASKEM.com "',varIntegranteAdminSelecionado='If(false, {ID: 0})')
add('Integrante: edição do próprio registro não acusa duplicidade',f'!IsBlank({dup})','false',Radar_Integrantes=TI,pEmail='"ana.silva@braskem.com"',varIntegranteAdminSelecionado='{ID: 1}')
# ---------- 5. Auditoria: duplicidade mês+dimensão ----------
sa=nocomments(P('TelaAuditoria.pa.yaml','btnSalvarAuditoria','OnSelect'))
reg=field(sa,'vRegistroExistente')
blk=re.search(r'!IsBlank\(vRegistroExistente\.ID\) && \(varModoAuditoria = "Novo" \|\| vRegistroExistente\.ID <> Coalesce\(varRegistroAuditoriaSelecionado\.ID, 0\)\)',flat(sa)).group(0)
TA='Table({ID: 10, MesReferencia: "2026-10", DimensaoAvaliada: {Value: "Documentacao"}, StatusRegistro: {Value: "Aberto"}}, {ID: 11, MesReferencia: "2026-10", DimensaoAvaliada: {Value: "Competencia"}, StatusRegistro: {Value: "Cancelado"}})'
for desc,modo,sel,dim,st,exp in [('Novo com dimensão já avaliada no mês','Novo','If(false, {ID: 0})','Documentacao','Aberto','true'),
    ('Novo quando o único existente está Cancelado','Novo','If(false, {ID: 0})','Competencia','Aberto','false'),
    ('Editar o próprio registro','Editar','{ID: 10}','Documentacao','Aberto','false'),
    ('Editar outro registro para dimensão ocupada','Editar','{ID: 11}','Documentacao','Aberto','true'),
    ('Cancelar registro não sofre bloqueio','Editar','{ID: 11}','Documentacao','Cancelado','false'),
    ('Novo em dimensão livre','Novo','If(false, {ID: 0})','Melhoria Continua','Aberto','false')]:
    add(f'Auditoria duplicidade: {desc}',f'With({{vRegistroExistente: {reg}}}, {blk})',exp,Radar_GestaoAuditoria_LCQ=TA,vMes='"2026-10"',vDimensao=f'"{dim}"',vStatusRegistro=f'"{st}"',varModoAuditoria=f'"{modo}"',varRegistroAuditoriaSelecionado=sel)
vis=P('TelaAuditoria.pa.yaml','btnNovoRegistroAuditoria','Visible')
for lid,adm,exp in [('false','false','false'),('true','false','true'),('true','true','true')]:
    add(f'Auditoria: botão Novo visível lid={lid} adm={adm}',vis,exp,varEhLideranca=lid,varEhAdmin=adm)
# ---------- 6. Rotina: mínimo 3 / máximo 6 por autor+semana+categoria ----------
se=nocomments(P('TelaRadarSemanal.pa.yaml','btnEnviarRotina','OnSelect'))
k=se.index('With(',se.index('Limite oficial')) if 'Limite oficial' in se else None
k=se.index('With(\n',se.index('NotificationType.Warning',se.index('Para concluir')))
lim=se[k:_match_end(se,k+4)].replace('User().Email','pEmail')
mn=re.search(r'vHighlights < 3 \|\| vLowlights < 3 \|\| vPontosPauta < 3',flat(se)).group(0)
def regs(n,tipo,email='eu@braskem.com',sem='2026-S41'): return [f'{{SemanaReferencia: "{sem}", CriadoPor: "{email}", TipoRegistro: {{Value: "{tipo}"}}}}']*n
def local(n,salvo='false'): return 'Table('+', '.join([f'{{Texto: "item {x}", Salvo: {salvo}}}' for x in range(n)])+')' if n else 'Filter(Table({Texto: "", Salvo: false}), false)'
def base(lst): return 'Table('+', '.join(lst)+')' if lst else 'Filter(Table({SemanaReferencia: "", CriadoPor: "", TipoRegistro: {Value: ""}}), false)'
cases=[('3 novos de cada, nada gravado','false',[],3,3,3),
 ('6 novos de cada, nada gravado','false',[],6,6,6),
 ('4 Highlights gravados + 3 novos = 7','true',regs(4,'Highlight'),3,3,3),
 ('3 gravados + 3 novos = 6 (limite exato)','false',regs(3,'Highlight')+regs(3,'Lowlight')+regs(3,'PontoDePauta'),3,3,3),
 ('6 de outro autor não contam (sem máximo global)','false',regs(6,'Highlight','outro@braskem.com'),3,3,3),
 ('6 do mesmo autor em outra semana não contam','false',regs(6,'Highlight',sem='2026-S40'),3,3,3),
 ('5 Concentrações gravadas + 3 novas = 8','true',regs(5,'PontoDePauta'),3,3,3)]
for desc,exp,b,h,l,p in cases:
    add(f'Rotina limite 6: {desc}',lim,exp,pEmail='"Eu@Braskem.com"',vSemana='"2026-S41"',colRegistrosRotinaBase=base(b),colHighlightsSemana=local(h),colLowlightsSemana=local(l),colPontosPautaSemana=local(p))
for h,l,p,exp in [(3,3,3,'false'),(2,3,3,'true'),(3,3,2,'true'),(6,3,3,'false')]:
    add(f'Rotina mínimo 3: H{h} L{l} C{p} bloqueado',mn,exp,vHighlights=str(h),vLowlights=str(l),vPontosPauta=str(p))
# ---------- 7. Bloqueios / Encaminhamentos: status exato ----------
eq=nocomments(P('TelaEquipamentos.pa.yaml','btnConcluirBloqueio','OnSelect'))
pk=field(eq,'vStatus').replace('Choices(Radar_Bloqueios.Status)','pChoices')
add('Bloqueio Concluir: opção Resolvido existe',f'{pk}.Value','Resolvido',pChoices='Table({Value: "Aberto"}, {Value: "Resolvido"}, {Value: "Cancelado"})')
add('Bloqueio Concluir: só "Concluído" existe',f'{pk}.Value','Concluído',pChoices='Table({Value: "Aberto"}, {Value: "Concluído"})')
add('Bloqueio Concluir: sem opção exata (apenas "Em resolução") -> Blank, Patch não executa',f'IsBlank({pk}.Value)','true',pChoices='Table({Value: "Aberto"}, {Value: "Em resolução"})')
ec=nocomments(P('TelaEquipamentos.pa.yaml','btnCancelarStatusBloqueio','OnSelect'))
pc=field(ec,'vStatus').replace('Choices(Radar_Bloqueios.Status)','pChoices')
add('Bloqueio Cancelar: opção Cancelado',f'{pc}.Value','Cancelado',pChoices='Table({Value: "Aberto"}, {Value: "Cancelado"})')
add('Bloqueio Cancelar: ausente -> Blank',f'IsBlank({pc}.Value)','true',pChoices='Table({Value: "Aberto"}, {Value: "Resolvido"})')
ov=nocomments(P('TelaEquipamentos.pa.yaml','TelaEquipamentos','OnVisible'))
enc=field(ov[ov.index('colBloqueiosTela'):],'Encerrado')
for st,exp in [('Aberto','false'),('Resolvido','true'),('Cancelado','true'),('Em resolução','false'),('Concluído','true')]:
    add(f'Bloqueio encerrado? status={st}',f'With({{Status: {{Value: "{st}"}}}}, {enc})',exp)
ab=nocomments(P('TelaEquipamentos.pa.yaml','btnAbrirBloqueio','OnSelect'))
pe=field(ab,'vPodeEditar').replace('ThisItem','pItem')
for desc,lid,adm,item,exp in [('Integrante responsável','false','false','{ResponsavelEmail: "eu@x.com", CriadorEmail: "a@x.com"}','true'),
    ('Integrante criador','false','false','{ResponsavelEmail: "b@x.com", CriadorEmail: "eu@x.com"}','true'),
    ('Integrante sem vínculo','false','false','{ResponsavelEmail: "b@x.com", CriadorEmail: "a@x.com"}','false'),
    ('Liderança sem vínculo','true','false','{ResponsavelEmail: "b@x.com", CriadorEmail: "a@x.com"}','true')]:
    add(f'Bloqueio edição: {desc}',pe,exp,varEhLideranca=lid,varEhAdmin=adm,varUsuarioAtual='"eu@x.com"',pItem=item)
de=nocomments(P('TelaDecisoesEncaminhamentos.pa.yaml','btnAbrirEncaminhamento','OnSelect'))
pa=setarg(de,'varPodeAtualizarEncaminhamento').replace('ThisItem','pItem')
for desc,lid,item,exp in [('Integrante responsável','false','{ResponsavelEmail: "eu@x.com"}','true'),('Integrante não responsável','false','{ResponsavelEmail: "b@x.com"}','false'),('Liderança','true','{ResponsavelEmail: "b@x.com"}','true')]:
    add(f'Encaminhamento atualização: {desc}',pa,exp,varEhLideranca=lid,varEhAdmin='false',varUsuarioAtual='"eu@x.com"',pItem=item)
dv=nocomments(P('TelaDecisoesEncaminhamentos.pa.yaml','TelaDecisoesEncaminhamentos','OnVisible'))
atr=field(dv[dv.index('colEncaminhamentosTela'):],'Atrasado').replace('Today()','Date(2026,10,6)')
for desc,st,prazo,exp in [('aberto vencido','Aberto','Date(2026,10,1)','true'),('aberto no prazo','Aberto','Date(2026,10,9)','false'),('concluído vencido','Concluído','Date(2026,10,1)','false'),('sem prazo','Aberto','Blank()','false')]:
    add(f'Encaminhamento atrasado: {desc}',f'With({{Status: {{Value: "{st}"}}, Prazo: {prazo}}}, {atr})',exp)
sem=setarg(dv,'varSemanaDecisoes').replace('Today()','pHoje')
for d,exp in [('Date(2026,10,6)','2026-S41'),('Date(2021,1,1)','2020-S53'),('Date(2024,12,30)','2025-S01'),('Date(2026,1,1)','2026-S01')]:
    add(f'Semana ISO {d}',sem,exp,pHoje=d)
sdd=nocomments(P('TelaDecisoesEncaminhamentos.pa.yaml','btnSalvarDecisao','OnSelect'))
assert '"^[0-9]{4}-S(0[1-9]|[1-4][0-9]|5[0-3])$"' in sdd
json.dump(T,open('tests_spec.json','w'),ensure_ascii=False,indent=1)
print(len(T),'casos')
