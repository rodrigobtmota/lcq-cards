import sys,re
def rep(path,old,new,count=1):
    s=open(path,encoding='utf-8').read()
    n=s.count(old)
    if n!=count: raise SystemExit(f'ERRO {path}: esperado {count} ocorrência(s), achou {n} para: {old[:120]!r}')
    s=s.replace(old,new)
    open(path,'w',encoding='utf-8').write(s)
def ind(text,n):
    return '\n'.join((' '*n+l) if l.strip() else '' for l in text.split('\n'))

def _find_ctl(lines,ctl):
    hits=[i for i,l in enumerate(lines) if re.match(r'^\s*(- )?'+re.escape(ctl)+r':\s*$',l)]
    if len(hits)!=1: raise SystemExit(f'ERRO controle {ctl}: {len(hits)} ocorrências')
    i=hits[0]; base=len(lines[i])-len(lines[i].lstrip())
    j=i+1
    while j<len(lines) and (not lines[j].strip() or len(lines[j])-len(lines[j].lstrip())>base): j+=1
    return i,j
def prop_span(lines,ctl,prop):
    i,j=_find_ctl(lines,ctl)
    # Properties: line directly under control
    pi=None
    for k in range(i,j):
        if lines[k].strip()=='Properties:': pi=k; break
    if pi is None: raise SystemExit('sem Properties')
    pind=len(lines[pi+1])-len(lines[pi+1].lstrip())
    for k in range(pi+1,j):
        l=lines[k]
        if l.strip() and len(l)-len(l.lstrip())<pind: break
        if len(l)-len(l.lstrip())==pind and l.lstrip().startswith(prop+':'):
            e=k+1
            while e<j and (not lines[e].strip() or len(lines[e])-len(lines[e].lstrip())>pind): e+=1
            while lines[e-1].strip()=='' : e-=1
            return k,e,pind,pi
    return None,None,pind,pi
def get_prop(path,ctl,prop):
    L=open(path,encoding='utf-8').read().split('\n')
    k,e,pind,_=prop_span(L,ctl,prop)
    if k is None: return None
    first=L[k].split(':',1)[1].strip()
    if first in ('|-','|'):
        return '\n'.join(x[pind+2:] for x in L[k+1:e])
    return first
def set_prop(path,ctl,prop,formula):
    """formula sem '=' inicial; grava como bloco literal; insere em ordem alfabética se não existir"""
    L=open(path,encoding='utf-8').read().split('\n')
    k,e,pind,pi=prop_span(L,ctl,prop)
    body=('='+formula).split('\n')
    if len(body)==1 and not formula.startswith(' ') and ': ' not in formula and '#' not in formula and not formula.startswith(('"',"'",'{','[','|','>','*','&','!','%','@','`')):
        new=[' '*pind+f'{prop}: ={formula}']
    else:
        new=[' '*pind+f'{prop}: |-']+[(' '*(pind+2)+x) if x.strip() else '' for x in body]
    if k is None:
        # inserir em ordem alfabética
        ins=pi+1
        _,j=_find_ctl(L,ctl)
        m=pi+1
        while m<j:
            l=L[m]
            if l.strip() and len(l)-len(l.lstrip())<pind: break
            if l.strip() and len(l)-len(l.lstrip())==pind:
                key=l.strip().split(':')[0]
                if key>prop: break
                ins=m+1
                while ins<j and (not L[ins].strip() or len(L[ins])-len(L[ins].lstrip())>pind): ins+=1
                while L[ins-1].strip()=='': ins-=1
            m+=1
        L[ins:ins]=new
    else:
        L[k:e]=new
    open(path,'w',encoding='utf-8').write('\n'.join(L))
def del_prop(path,ctl,prop):
    L=open(path,encoding='utf-8').read().split('\n')
    k,e,_,_=prop_span(L,ctl,prop)
    if k is None: raise SystemExit(f'prop {prop} não existe em {ctl}')
    del L[k:e]; open(path,'w',encoding='utf-8').write('\n'.join(L))

def _match_end(t,i):
    """t[i]=='(' -> índice após o ')' correspondente; ignora strings e comentários"""
    d=0; k=i; n=len(t)
    while k<n:
        ch=t[k]
        if ch=='"':
            k+=1
            while k<n:
                if t[k]=='"':
                    if k+1<n and t[k+1]=='"': k+=2; continue
                    break
                k+=1
        elif t.startswith('//',k):
            while k<n and t[k]!='\n': k+=1
            continue
        elif ch in '([{': d+=1
        elif ch in ')]}':
            d-=1
            if d==0: return k+1
        k+=1
    raise SystemExit('parênteses não balanceados')
def _expr_end(t,i):
    """a partir de i, avança até a vírgula/fechamento de nível 0 (não consome)"""
    k=i; n=len(t)
    while k<n:
        ch=t[k]
        if ch=='"':
            k+=1
            while k<n:
                if t[k]=='"':
                    if k+1<n and t[k+1]=='"': k+=2; continue
                    break
                k+=1
            k+=1; continue
        if ch in '([{': k=_match_end(t,k); continue
        if ch in ',)]};': return k
        k+=1
    return k
def remove_switch_case(t,key):
    cnt=0
    while True:
        m=re.search(r'"'+re.escape(key)+r'"\s*,',t)
        if not m: return t,cnt
        e=_expr_end(t,m.end())
        if t[e]!=',': raise SystemExit('caso de Switch sem vírgula final: '+t[m.start():e+40])
        e+=1
        while e<len(t) and t[e] in ' \t\n': e+=1
        s=m.start()
        t=t[:s]+t[e:]; cnt+=1
def remove_calls(t,pattern):
    """remove chamadas inteiras que casam com pattern (regex que termina em '(' ), + ';' seguinte"""
    cnt=0
    while True:
        m=re.search(pattern,t)
        if not m: return t,cnt
        e=_match_end(t,m.end()-1)
        k=e
        while k<len(t) and t[k] in ' \t\n': k+=1
        if k<len(t) and t[k]==';': e=k+1
        # remove espaço anterior em linha
        s=m.start()
        while e<len(t) and t[e] in ' \t\n': e+=1
        t=t[:s]+t[e:]; cnt+=1
def remove_plus_term(t,pattern):
    cnt=0
    while True:
        m=re.search(r'\+\s*'+pattern,t)
        if not m: return t,cnt
        e=_match_end(t,m.end()-1)
        s=m.start()
        while s>0 and t[s-1] in ' \t\n': s-=1
        t=t[:s]+t[e:]; cnt+=1
