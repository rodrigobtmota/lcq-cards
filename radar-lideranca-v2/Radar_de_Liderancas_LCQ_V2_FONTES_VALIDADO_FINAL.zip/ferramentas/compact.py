import yaml,sys,re
sys.path.insert(0,'.')
STYLE=set(open(sys.argv[0].replace('compact.py','tree.py')).read().split("STYLE=set('''")[1].split("'''")[0].split())
def comp(s):
    s=re.sub(r'//[^\n"]*\n','\n',s)
    s=re.sub(r'\s*\n\s*',' ',s); s=re.sub(r'\(\s+','(',s); s=re.sub(r'\s+\)',')',s); s=re.sub(r'\{\s+','{',s); s=re.sub(r'\s+\}','}',s)
    return s.strip()
def walk(node,d):
    for item in node or []:
        for name,c in item.items():
            print('  '*d+f"- {name} [{c.get('Control')}]")
            for p,v in (c.get('Properties') or {}).items():
                if p in STYLE: continue
                s=comp(str(v))
                if p=='HtmlText' and len(s)>160: s=s[:160]+f' …[{len(s)}]'
                print('  '*d+f"    {p}: {s}")
            walk(c.get('Children'),d+1)
for f in sys.argv[1:]:
    dd=yaml.safe_load(open(f,encoding='utf-8'))
    for k,v in (dd.get('Screens') or {}).items():
        print('# SCREEN',k)
        for p,val in (v.get('Properties') or {}).items(): print(f"  {p}: {comp(str(val))}")
        walk(v.get('Children'),1)
