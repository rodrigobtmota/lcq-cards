import yaml,sys,re,collections
STYLE=set('''X Y Width Height Color Fill BorderColor BorderThickness BorderStyle Font FontWeight Size Align VerticalAlign PaddingTop PaddingBottom PaddingLeft PaddingRight RadiusTopLeft RadiusTopRight RadiusBottomLeft RadiusBottomRight HoverFill HoverColor PressedFill PressedColor DisabledFill DisabledColor HoverBorderColor PressedBorderColor DisabledBorderColor FocusedBorderThickness FocusedBorderColor ZIndex LayoutMinHeight LayoutMinWidth LayoutAlignItems LayoutDirection LayoutGap LayoutJustifyContent DropShadow FontItalic Italic Underline LineHeight Wrap TemplatePadding TemplateSize ShowScrollbar SelectionFill SelectionColor ChevronFill ChevronBackground ChevronHoverFill ChevronHoverBackground ChevronDisabledFill ChevronDisabledBackground ImagePosition AlignInContainer FillPortions LayoutMode AutoHeight BorderRadius LayoutOverflowY LayoutOverflowX LayoutWrap Transition HoverBorderThickness PressedBorderThickness RadiusTop Overflow VirtualKeyboardMode HintColor PaddingAll MaxHeight'''.split())
def walk(node,depth,out,screen,full):
    for item in node or []:
        for name,c in item.items():
            props=c.get('Properties',{}) or {}
            out.append((screen,name,c.get('Control'),depth))
            print('  '*depth+f"- {name} [{c.get('Control')}{' '+c['Variant'] if c.get('Variant') else ''}]")
            for p,v in props.items():
                if not full and p in STYLE: continue
                s=str(v)
                if "--trunc" in sys.argv and len(s)>600: s=s[:600]+' …'
                if "--nohtml" in sys.argv and p=="HtmlText" and len(s)>250: s=s[:250]+' …[HTML %d chars]'%len(s)
                print('  '*depth+f"    {p}: "+s.replace('\n','\n'+'  '*depth+'      '))
            walk(c.get('Children'),depth+1,out,screen,full)
full='--full' in sys.argv
for f in [a for a in sys.argv[1:] if not a.startswith('--')]:
    d=yaml.safe_load(open(f,encoding='utf-8'))
    for k,v in (d.get('Screens') or {}).items():
        print('# SCREEN',k)
        for p,val in (v.get('Properties') or {}).items(): print(f"  {p}: {val}")
        out=[];walk(v.get('Children'),1,out,k,full)
