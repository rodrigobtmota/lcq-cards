import yaml,json,sys,glob,re,collections
src=sys.argv[1]; schema=json.load(open(sys.argv[2],encoding='utf-8'))
files=sorted(glob.glob(src+'/**/*.pa.yaml',recursive=True))
screens={}; ctl_screen={}; formulas=[]  # (screen, control, prop, text)
def strip_strings(t):
    t=re.sub(r'"(?:[^"]|"")*"','""',t)
    t=re.sub(r'//[^\n]*','',t); t=re.sub(r'/\*.*?\*/','',t,flags=re.S)
    return t
def walk(node,scr):
    for item in node or []:
        for n,c in item.items():
            if n in ctl_screen and ctl_screen[n]!=scr: print('DUPLICATE_CONTROL_NAME',n,ctl_screen[n],scr)
            ctl_screen[n]=scr; screens[scr].add(n)
            for p,v in (c.get('Properties') or {}).items():
                if isinstance(v,str) and v.startswith('='): formulas.append((scr,n,p,v[1:]))
            walk(c.get('Children'),scr)
app=None
for f in files:
    d=yaml.safe_load(open(f,encoding='utf-8'))
    if 'App' in d:
        for p,v in d['App']['Properties'].items(): formulas.append(('App','App',p,v[1:]))
    for k,v in (d.get('Screens') or {}).items():
        screens[k]=set(); ctl_screen[k]=k
        for p,val in (v.get('Properties') or {}).items(): formulas.append((k,k,p,val[1:]))
        walk(v.get('Children'),k)
    for k,v in (d.get('ComponentDefinitions') or {}).items():
        screens['COMP:'+k]=set(); walk(v.get('Children'),'COMP:'+k)
allctl=set(ctl_screen)
DS=set(schema)|{'ClickabuttoninPowerAppstosendanemail','ComboBoxSample','CustomGallerySample','DropDownSample','RadioSample'}
gset=collections.defaultdict(set); ctxset=collections.defaultdict(set); colset=set()
for scr,c,p,t in formulas:
    s=strip_strings(t)
    for m in re.finditer(r'\bSet\(\s*(\w+)',s): gset[m.group(1)].add(scr)
    for m in re.finditer(r'\bUpdateContext\(\s*\{([^}]*)\}',s):
        for k in re.findall(r'(\w+)\s*:',m.group(1)): ctxset[scr].add(k)
    for m in re.finditer(r'\b(?:ClearCollect|Collect)\(\s*(\w+)',s): colset.add(m.group(1))
issues=collections.Counter(); out=[]
used=collections.Counter()
KEYW=set('If Switch And Or Not true false Self Parent ThisItem ThisRecord Blank'.split())
for scr,c,p,t in formulas:
    s=strip_strings(t)
    # Navigate targets
    for m in re.finditer(r'\bNavigate\(\s*(\w+)',s):
        if m.group(1) not in screens: out.append(f'NAV_INVALIDA {scr}.{c}.{p} -> {m.group(1)}')
    toks=set(re.findall(r"(?<![\.\w'])([A-Za-z_]\w*)\b(?!\s*:)",s))
    for tk in toks:
        used[tk]+=1
        if tk in allctl and not scr.startswith('COMP:') and scr!='App':
            if ctl_screen[tk]!=scr and tk not in screens: out.append(f'REF_OUTRA_TELA {scr}.{c}.{p} -> {tk} ({ctl_screen[tk]})')
        if tk.startswith('var') and tk not in gset and tk not in ctxset[scr]:
            out.append(f'VAR_NAO_INICIALIZADA {scr}.{c}.{p} -> {tk}')
        if tk.startswith('col') and tk not in colset and tk not in ('colMenu',):
            out.append(f'COLECAO_INDEFINIDA {scr}.{c}.{p} -> {tk}')
        if tk.startswith('Radar_') and tk not in DS: out.append(f'FONTE_INVALIDA {scr}.{c}.{p} -> {tk}')
    # Patch payload keys vs schema (display names)
    for m in re.finditer(r'\bPatch\(\s*(Radar_\w+)\s*,',s):
        dsn=m.group(1); i=m.end(); depth=0; j=i
        # find the record literal argument(s) after base
        rest=s[i:]; 
        # crude: take first top-level {...} after the second comma at depth 0
        d=0; commas=0; k=0; start=None
        while k<len(rest):
            ch=rest[k]
            if ch in '({[': 
                if ch=='{' and d==0 and commas>=1 and start is None: start=k
                d+=1
            elif ch in ')}]':
                d-=1
                if d<0: break
                if d==0 and start is not None and ch=='}':
                    rec=rest[start:k+1]
                    keys=re.findall(r'[\{,]\s*\'?([\wÀ-ú ]+?)\'?\s*:',rec)
                    valid={v['title'] for v in schema[dsn].values()}|set(schema[dsn])
                    # only top-level keys
                    dd=0; top=[]; buf=''
                    for kk in re.finditer(r"([\{\(\[\}\)\]])|(?:(?<=[\{,])\s*'?([\wÀ-ú ]+?)'?\s*:)",rec):
                        if kk.group(1):
                            dd+=1 if kk.group(1) in '{([' else -1
                        elif dd==1: top.append(kk.group(2).strip())
                    for key in top:
                        if key not in valid: out.append(f'PATCH_CAMPO_INVALIDO {scr}.{c}.{p} {dsn}.{key}')
                    start=None
            elif ch==',' and d==0: commas+=1
            k+=1
for o in sorted(set(out)): print(o)
print('---')
setnotused=[v for v in gset if used[v]<=1 and v.startswith('var')]
print('VARS_SET_NAO_LIDAS(aprox):',sorted(setnotused))
print('TOTAL_ISSUES=',len(set(out)))
