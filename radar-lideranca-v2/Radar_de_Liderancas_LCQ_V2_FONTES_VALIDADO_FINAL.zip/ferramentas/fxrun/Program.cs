using System.Text.Json;
using Microsoft.PowerFx;
using Microsoft.PowerFx.Types;
var spec = JsonDocument.Parse(File.ReadAllText(args[0])).RootElement;
int ok = 0, fail = 0;
foreach (var t in spec.EnumerateArray())
{
    var name = t.GetProperty("name").GetString();
    var cfg = new PowerFxConfig(); cfg.EnableSetFunction();
    var eng = new RecalcEngine(cfg);
    var opts = new ParserOptions { AllowsSideEffects = true, Culture = System.Globalization.CultureInfo.InvariantCulture };
    string got;
    try
    {
        foreach (var v in t.GetProperty("vars").EnumerateObject())
        {
            var r = eng.Eval(v.Value.GetString()!, null, opts);
            if (r is ErrorValue ev0) throw new Exception("var " + v.Name + ": " + string.Join(";", ev0.Errors.Select(e => e.Message)));
            eng.UpdateVariable(v.Name, r);
        }
        var res = eng.Eval(t.GetProperty("expr").GetString()!, null, opts);
        got = res switch
        {
            ErrorValue ev => "ERRO: " + string.Join(";", ev.Errors.Select(e => e.Message)),
            BlankValue => "Blank",
            StringValue s => s.Value,
            BooleanValue b => b.Value ? "true" : "false",
            NumberValue n => n.Value.ToString(System.Globalization.CultureInfo.InvariantCulture),
            DecimalValue d => d.Value.ToString(System.Globalization.CultureInfo.InvariantCulture),
            _ => res.ToObject()?.ToString() ?? "null"
        };
    }
    catch (Exception ex) { got = "EXCECAO: " + ex.Message; }
    var exp = t.GetProperty("expected").GetString();
    bool pass = got == exp;
    if (pass) ok++; else fail++;
    Console.WriteLine($"{(pass ? "PASS" : "FAIL")} | {name} | esperado={exp} | obtido={got}");
}
Console.WriteLine($"TOTAL PASS={ok} FAIL={fail}");
return fail == 0 ? 0 : 1;
