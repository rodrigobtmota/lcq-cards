import json,sys,zipfile
z=zipfile.ZipFile(sys.argv[1])
ds=json.loads(z.read('References\\DataSources.json').decode('utf-8-sig'))
out={}
for d in ds['DataSources']:
    if d.get('Type')!='ConnectedDataSourceInfo': continue
    m=json.loads(d['DataEntityMetadataJson'][d['TableName']]) if isinstance(d['DataEntityMetadataJson'],dict) else None
    sch=m['schema']['items']['properties']
    fields={}
    for k,v in sch.items():
        t=v.get('type'); fmt=v.get('format',''); xsp=v.get('x-ms-capabilities',{})
        title=v.get('title',k)
        kind=v.get('x-ms-sp-type') or ''
        if '$ref' in str(v) or t=='object': kind=kind or 'object'
        enum = None
        fields[k]=dict(title=title,type=t,fmt=fmt,ro=v.get('x-ms-permission')=='read-only',req=k in m['schema']['items'].get('required',[]),spt=v.get('x-ms-dynamic-values') and 'choice' or '')
    out[d['Name']]=fields
    print('\n##',d['Name'], d.get('ConnectedDataSourceInfoNameMapping') and '' )
    for k,f in fields.items():
        if k.startswith('{') or k in('Created','Modified','Author','Editor','OData__UIVersionString','Attachments','ComplianceAssetId','Author#Claims','Editor#Claims','{Identifier}'): continue
        print(f"  {k:32} title={f['title']:28} {f['type']}/{f['fmt']} {'RO' if f['ro'] else ''} {'REQ' if f['req'] else ''}")
json.dump(out,open(sys.argv[2],'w'),ensure_ascii=False,indent=1)
