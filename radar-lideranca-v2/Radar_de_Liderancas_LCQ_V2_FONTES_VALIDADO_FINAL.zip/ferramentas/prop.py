import yaml,sys
def find(node,name):
    for item in node or []:
        for n,c in item.items():
            if n==name: return c
            r=find(c.get('Children'),name)
            if r: return r
d=yaml.safe_load(open(sys.argv[1],encoding='utf-8'))
scr=list(d['Screens'].values())[0]
c=find(scr['Children'],sys.argv[2])
if len(sys.argv)>3: print(c['Properties'][sys.argv[3]])
else: print(yaml.safe_dump(c,allow_unicode=True,sort_keys=False,width=10000))
