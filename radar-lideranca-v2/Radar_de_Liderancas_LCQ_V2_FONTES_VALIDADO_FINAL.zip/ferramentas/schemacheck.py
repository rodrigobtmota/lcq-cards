import yaml,json,sys,glob,jsonschema
schema=yaml.safe_load(open(sys.argv[1],encoding='utf-8'))
v=jsonschema.Draft7Validator(schema)
bad=0
for f in sorted(glob.glob(sys.argv[2]+'/**/*.pa.yaml',recursive=True)):
    d=yaml.safe_load(open(f,encoding='utf-8'))
    errs=list(v.iter_errors(d))
    for e in errs[:20]: print('SCHEMA',f.split('/')[-1],list(e.absolute_path)[:8],e.message[:200])
    bad+=len(errs)
print('SCHEMA_ERRORS=',bad)
