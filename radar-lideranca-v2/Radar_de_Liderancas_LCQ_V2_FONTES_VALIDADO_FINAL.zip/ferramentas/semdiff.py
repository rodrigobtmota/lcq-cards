import yaml,sys,glob,re,difflib,os
def norm(s):
    s=re.sub(r'(?m)//.*$','',s) if '"' not in s else re.sub(r'(?m)^\s*//.*$','',s)
    return re.sub(r'\s+',' ',s).strip()
def toks(s): return re.findall(r'"(?:[^"]|"")*"|\w+|[^\s\w]',s)
def load(d):
    out={}; ctrls={}
    for f in glob.glob(d+'/**/*.pa.yaml',recursive=True):
        y=yaml.safe_load(open(f,encoding='utf-8'))
        if 'App' in y:
            for p,v in y['App']['Properties'].items(): out[('App','App',p)]=str(v)
        for k,v in (y.get('Screens') or {}).items():
            for p,val in (v.get('Properties') or {}).items(): out[(k,k,p)]=str(val)
            def walk(node,par):
                for it in node or []:
                    for n,c in it.items():
                        ctrls[(k,n)]=(c.get('Control'),par)
                        for p,val in (c.get('Properties') or {}).items(): out[(k,n,p)]=str(val)
                        walk(c.get('Children'),n)
            walk(v.get('Children'),k)
    return out,ctrls
a,ca=load(sys.argv[1]); b,cb=load(sys.argv[2]); verbose='-v' in sys.argv
filt=[x for x in sys.argv[3:] if not x.startswith('-')]
print('## Controles adicionados'); [print('+',k,cb[k][0]) for k in sorted(set(cb)-set(ca))]
print('## Controles removidos'); [print('-',k,ca[k][0]) for k in sorted(set(ca)-set(cb))]
print('## Controles com tipo/pai alterado'); [print('~',k,ca[k],'->',cb[k]) for k in sorted(set(ca)&set(cb)) if ca[k]!=cb[k]]
print('## Propriedades alteradas')
for k in sorted(set(a)|set(b)):
    if filt and not any(f in k[1] or f==k[0] for f in filt): continue
    x=norm(a.get(k,'<ausente>')); y=norm(b.get(k,'<ausente>'))
    if x==y: continue
    if k[1] in [c[1] for c in set(cb)-set(ca)] : continue
    tag='NOVA' if k not in a else 'REMOVIDA' if k not in b else 'ALTERADA'
    print(f'* {tag} {k[0]}.{k[1]}.{k[2]}')
    if verbose and tag=='ALTERADA':
        ta,tb=toks(x),toks(y)
        for op,i1,i2,j1,j2 in difflib.SequenceMatcher(None,ta,tb,autojunk=False).get_opcodes():
            if op=='equal': continue
            print(f'    {op}: -[{" ".join(ta[i1:i2])[:400]}]  +[{" ".join(tb[j1:j2])[:400]}]')
