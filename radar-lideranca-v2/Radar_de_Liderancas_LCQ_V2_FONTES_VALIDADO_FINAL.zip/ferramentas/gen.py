import re,sys
sys.path.insert(0,__file__.rsplit('/',1)[0])
from rep import _find_ctl
SAFE=re.compile(r'^[^\n#]*$')
def _pv(k,v,ind):
    v=v.strip('\n')
    one=('\n' not in v) and ': ' not in v and ' #' not in v and not v.startswith(('"',"'",'{','[','|','>','*','&','!','%','@','`',' '))
    if one: return [' '*ind+f'{k}: ={v}']
    return [' '*ind+f'{k}: |-']+[(' '*(ind+2)+l) if l.strip() else '' for l in ('='+v).split('\n')]
def C(name,control,props=None,children=None,variant=None,component=None):
    return dict(name=name,control=control,props=props or {},children=children or [],variant=variant,component=component)
def emit(c,ind):
    L=[' '*ind+f"- {c['name']}:"]
    i2=ind+4
    L.append(' '*i2+f"Control: {c['control']}")
    if c['variant']: L.append(' '*i2+f"Variant: {c['variant']}")
    if c['component']: L.append(' '*i2+f"ComponentName: {c['component']}")
    if c['props']:
        L.append(' '*i2+'Properties:')
        for k in sorted(c['props']): L+= _pv(k,c['props'][k],i2+2)
    if c['children']:
        L.append(' '*i2+'Children:')
        for ch in c['children']: L+=emit(ch,i2+2)
    return L
def insert_after(path,anchor,ctls):
    L=open(path,encoding='utf-8').read().split('\n')
    i,j=_find_ctl(L,anchor)
    while L[j-1].strip()=='': j-=1
    ind=len(L[i])-len(L[i].lstrip())
    new=[]
    for c in ctls: new+=emit(c,ind)
    L[j:j]=new; open(path,'w',encoding='utf-8').write('\n'.join(L))
def insert_before(path,anchor,ctls):
    L=open(path,encoding='utf-8').read().split('\n')
    i,j=_find_ctl(L,anchor)
    ind=len(L[i])-len(L[i].lstrip())
    new=[]
    for c in ctls: new+=emit(c,ind)
    L[i:i]=new; open(path,'w',encoding='utf-8').write('\n'.join(L))
