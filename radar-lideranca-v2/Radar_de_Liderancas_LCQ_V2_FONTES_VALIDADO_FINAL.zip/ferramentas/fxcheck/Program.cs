using System.Globalization;
using Microsoft.PowerFx;
using Microsoft.PowerFx.Syntax;
using YamlDotNet.RepresentationModel;

int total = 0, errors = 0;
var opts = new ParserOptions { AllowsSideEffects = true, Culture = CultureInfo.InvariantCulture };
void Check(string file, string path, string text)
{
    total++;
    var res = Engine.Parse(text, null, opts);
    if (!res.IsSuccess)
    {
        errors++;
        foreach (var e in res.Errors)
            Console.WriteLine($"ERR {Path.GetFileName(file)} :: {path} :: {e.Message} @ {e.Span?.Min}");
    }
}
void Walk(string file, YamlNode node, string path, bool inProps)
{
    switch (node)
    {
        case YamlMappingNode m:
            foreach (var kv in m.Children)
            {
                var key = ((YamlScalarNode)kv.Key).Value!;
                bool props = key == "Properties" || (key == "Default" && path.Contains("CustomProperties"));
                if (key == "Default" && path.Contains("CustomProperties") && kv.Value is YamlScalarNode ds && ds.Value!.StartsWith("="))
                { Check(file, path + "/" + key, ds.Value.Substring(1)); continue; }
                Walk(file, kv.Value, path + "/" + key, props || (inProps && false));
            }
            break;
        case YamlSequenceNode s:
            foreach (var c in s.Children) Walk(file, c, path, false);
            break;
        case YamlScalarNode sc:
            if (path.Contains("/Properties/") && sc.Value != null && sc.Value.StartsWith("="))
                Check(file, path, sc.Value.Substring(1));
            break;
    }
}
foreach (var f in Directory.GetFiles(args[0], "*.pa.yaml", SearchOption.AllDirectories))
{
    var ys = new YamlStream();
    using var r = new StreamReader(f);
    ys.Load(r);
    foreach (var d in ys.Documents) Walk(f, d.RootNode, "", false);
}
Console.WriteLine($"FORMULAS={total} SYNTAX_ERRORS={errors}");
return errors == 0 ? 0 : 1;
