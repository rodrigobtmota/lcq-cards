# Fontes validadas — Radar de Lideranças LCQ V2

- `fontes/` — saída de `pac canvas unpack --layout SourceCode` (pasta `Src/*.pa.yaml` + `.msapr`). Reempacotar:
  `pac canvas pack --sources fontes --msapp Radar.msapp --layout SourceCode`
- `ferramentas/` — validadores usados:
  - `fxcheck/` (parser oficial Microsoft.PowerFx.Core 1.8.1): `dotnet run -- <pasta Src>`
  - `schemacheck.py` + `pa.schema.yaml` (schema oficial v3.0): `python3 schemacheck.py pa.schema.yaml <pasta Src>`
  - `refcheck.py` + `schema.json` (schema real das listas extraído do .msapp): `python3 refcheck.py <pasta Src> schema.json`
  - `gen_tests.py` + `fxrun/` (Microsoft.PowerFx.Interpreter 1.8.1): gera e executa os 74 casos críticos
  - `semdiff.py`: diff semântico entre duas pastas Src
  - `build/`: scripts que geraram os módulos Bloqueios e Decisões/Encaminhamentos
- `evidencias/` — saídas das execuções (round-trip, testes, cobertura de Patch, diff).

As fórmulas estão na sintaxe invariante gravada pelo Power Apps (`,` / `;`); o Studio em pt-BR exibe `;` / `;;`.
